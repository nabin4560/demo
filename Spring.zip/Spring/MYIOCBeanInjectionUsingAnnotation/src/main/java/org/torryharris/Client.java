package org.torryharris;

public interface Client {
    void doSomething();
}

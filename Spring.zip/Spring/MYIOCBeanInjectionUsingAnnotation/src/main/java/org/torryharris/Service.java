package org.torryharris;

public interface Service {
    public String getInfo();
}

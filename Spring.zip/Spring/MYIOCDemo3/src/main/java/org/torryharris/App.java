package org.torryharris;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context = new ClassPathXmlApplicationContext("file:src/main/java/org/torryharris/beans.xml");
        THClient c1 = (THClient) context.getBean("client1");
        System.out.println(c1.deposit(1234L,10000.0));
        System.out.println();
        System.out.println(c1.withdraw(1234l,4000.0));
        System.out.println(c1.getBalance(1234l));

        THClient c2 = (THClient) context.getBean("client1");
        System.out.println(c2.deposit(1234L,10000.0));
        System.out.println();
        System.out.println(c2.withdraw(1234l,4000.0));
        System.out.println(c2.getBalance(1234l));

        ((ClassPathXmlApplicationContext) context).close();
    }
}

package org.torryharris;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
        context.scan("org.torryharris");
        context.refresh();

        Customer customer = (Customer)context.getBean("customer");
        customer.setCustId(100);
        customer.setCustName("nabin");

        Address address = customer.getAddress();
        address.setDoorNo("17");
        address.setStreet("sambhram");
        address.setCity("Bangalore");
        address.setState("karnataka");
        address.setPin("560097");

        System.out.println(customer);
    }
}

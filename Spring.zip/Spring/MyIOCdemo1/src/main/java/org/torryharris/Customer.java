package org.torryharris;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@ToString
@Getter
@Setter
public class Customer {
    private int custId;
    private String custName;
    private Address addrs;
    private Account account;
    public Customer(Address addrs) {
        this.addrs = addrs;
    }

    public Customer(Account account) {
        this.account = account;
    }
    /*public Customer(int custId, String custName, Address address) {
        this.custId = custId;
        this.custName = custName;
        this.address = address;
    }
*/
}
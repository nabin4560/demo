package org.torryharris;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {


        ApplicationContext context =new ClassPathXmlApplicationContext("file:src/main/java/beans.xml");
        Customer customer = (Customer)context.getBean("customer");
        customer.setCustId(100);
        customer.setCustName("nabin");

        Address address = (Address)customer.getAddrs();
        address.setDoorNo("17");
        address.setStreet("sambhram");
        address.setCity("karnataka");
        address.setPin("560097");

        Account account =(Account)customer.getAccount();
        account.setAccNo(1001);
        account.setBankName("HDFC");
        account.setAccType("saving");
        System.out.println(customer);


    }
}

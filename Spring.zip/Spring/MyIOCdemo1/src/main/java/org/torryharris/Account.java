package org.torryharris;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@ToString
@Getter
@Setter
public class Account {
    private int accNo;
    private String bankName;
    private String accType;

}

package org.example;

public class ServiceB implements Service {

    public ServiceB() {
    }

    @Override
    public String getInfo() {
        return "ServiceB info";
    }
}
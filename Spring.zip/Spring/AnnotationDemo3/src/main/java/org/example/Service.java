package org.example;

public interface Service {
    public String getInfo();
}

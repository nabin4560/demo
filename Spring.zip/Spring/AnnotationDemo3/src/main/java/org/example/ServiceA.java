package org.example;


public class ServiceA implements Service {
    @Override
    public String getInfo() {
        return "ServiceA info";
    }
}

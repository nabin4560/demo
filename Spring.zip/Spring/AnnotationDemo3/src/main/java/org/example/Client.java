package org.example;

public interface Client {
    void doSomething();
}

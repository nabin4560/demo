package org.torryharris;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        Address address = new Address("17","sambhram","bangalore","karnataka","58000");


        Customer cust = new Customer(100,"nabin",address);

        System.out.println(cust);
    }
}

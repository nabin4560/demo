package com.torryharris.device;

public class Brand extends Laptop{
    private String brandName;
    private String brandColor;

    public Brand(int cost,String brandName,String brandColor) {
        super(cost);
        this.brandName=brandName;
        this.brandColor=brandColor;
    }


    @Override
    public int ram(int n) {
        return n;
    }

    @Override
    public int rom(int n) {
        return n;
    }
    @Override
    public int newProcessor(int n )
    {
        return n;
    }

    @Override
    public int price(int n)
    {
        int processor =n;
        if(processor ==7)
            return  cost+20000;


        else if (processor==5)
            return cost+15000;
        else
            return +cost;


    }

    @Override
    public String toString() {
        return "Brand{" +
                "brandName='" + brandName + '\'' +
                ", brandColor='" + brandColor + '\'' +
                ", cost=" + cost +
                ", lap_ram=" + lap_ram +
                ", lap_rom=" + lap_rom +
                ", lapprocessor=" + lapprocessor +
                ", gen=" + gen +
                '}';
    }
}

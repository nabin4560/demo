package com.torryharris.device;

public abstract class Laptop implements Device{

    protected  int cost =40000;
    protected final int lap_ram=4;
    protected final int lap_rom=128;
    protected final int lapprocessor=3;
    protected final int gen = 10;

    public Laptop(int cost) {
        this.cost = cost;
    }

    @Override
    public String lanuch() {
        return "laptop lanuched!!!";
    }

    @Override
    public abstract int price(int n) ;



    @Override
    public String shipped() {
        return "laptop is ready to shipped!!!";
    }
    @Override
    public abstract int ram(int n) ;
    @Override
    public abstract int rom(int n) ;
    @Override
    public abstract int newProcessor(int n) ;


}

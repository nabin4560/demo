package com.torryharris.device;

public interface Device {
    String lanuch();
    int price(int n);
    String shipped();
    int ram(int n);
    int rom(int n);
    int newProcessor(int n);



}

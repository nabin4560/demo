package com.company;

import com.torryharris.device.Brand;
import com.torryharris.device.Laptop;

public class Main {

    public static void main(String[] args) {
        Laptop lap1 = new Brand(40000,"dell","black");
        Laptop lap2 = new Brand(35000,"acer","red");
        System.out.println(lap1.lanuch());
        System.out.println(lap1+"\n"+lap2);
        System.out.println(lap1.shipped());

        // to check laptop price of different version

        int newRam = lap1.ram(8);
        int newRom = lap1.rom(512);
        int processor =lap1.newProcessor(5);
        int amt = lap1.price(5);



        System.out.println("latest config: \n"+"ram: "+newRam+" rom: " +newRom+" Processor: "+processor+" laptop price "+amt);







    }
}

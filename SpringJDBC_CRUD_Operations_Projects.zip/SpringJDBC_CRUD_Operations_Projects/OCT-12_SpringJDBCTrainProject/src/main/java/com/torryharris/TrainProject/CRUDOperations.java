package com.torryharris.TrainProject;



import com.torryharris.TrainProject.Train;

public interface CRUDOperations {
	
	public void insert(Train train);
	

}


package com.torryharris.JDBCSpring;



public interface CRUDOperations {
	
	public void insert(Book book);

}
